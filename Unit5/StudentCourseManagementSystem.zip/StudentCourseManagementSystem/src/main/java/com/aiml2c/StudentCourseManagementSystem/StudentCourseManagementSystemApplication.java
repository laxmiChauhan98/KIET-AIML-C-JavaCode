package com.aiml2c.StudentCourseManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCourseManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentCourseManagementSystemApplication.class, args);
	}

}
